from django.contrib import admin
from .import models

# Register your models here.

admin.site.register(models.CallReq)
admin.site.register(models.contactMsg)
admin.site.register(models.Intermship)
admin.site.register(models.Careers)