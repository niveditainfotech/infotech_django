let img=document.querySelector(".navbtn/img")
let nav=document.querySelector(".mobnav")


img.addEventListener("click",()=>{
    nav.classList.toggle("show");
})